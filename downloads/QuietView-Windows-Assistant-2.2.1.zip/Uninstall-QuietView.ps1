﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'

$nativeName = 'local.quietview.frame'
$nativeManifestPath = Join-Path $PSScriptRoot "$nativeName.json"
$registryPaths = @(
    'Software\Google\Chrome\NativeMessagingHosts',
    'Software\Microsoft\Edge\NativeMessagingHosts'
)

foreach ($registryPath in $registryPaths) {
    $parentEntry = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($registryPath, $true)
    if (-not $parentEntry) { continue }
    try {
        $entry = $parentEntry.OpenSubKey($nativeName, $true)
        if (-not $entry) { continue }
        $removeEmptyKey = $false
        try {
            $registeredPath = [string]$entry.GetValue('', '')
            if ([string]::Equals($registeredPath, $nativeManifestPath, [StringComparison]::OrdinalIgnoreCase)) {
                $entry.DeleteValue('', $false)
                $removeEmptyKey = ($entry.ValueCount -eq 0 -and $entry.SubKeyCount -eq 0)
            }
        } finally {
            $entry.Dispose()
        }
        if ($removeEmptyKey) { $parentEntry.DeleteSubKey($nativeName, $false) }
    } finally {
        $parentEntry.Dispose()
    }
}

if (Test-Path -LiteralPath $nativeManifestPath -PathType Leaf) {
    $candidate = $null
    try {
        $candidate = Get-Content -LiteralPath $nativeManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        # 只删除能识别为当前安装生成的配置文件。
    }
    if ($candidate.name -eq $nativeName -and $candidate.path -eq 'QuietView.Host.exe' -and
        $candidate.type -eq 'stdio') {
        [IO.File]::Delete($nativeManifestPath)
    }
}

Write-Host '当前安装包的 Windows 组件注册已移除。可在浏览器的扩展管理页面移除净览。'
