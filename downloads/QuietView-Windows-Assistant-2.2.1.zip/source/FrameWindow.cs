using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

internal sealed class FrameWindow : IDisposable
{
    private const int DwmExtendedFrameBounds = 9;
    private const uint QueryLimitedInformation = 0x1000;
    private const uint NoZOrderOrActivate = 0x0004 | 0x0010;
    private static readonly IntPtr PerMonitorAwareV2 = new IntPtr(-4);
    private static readonly IntPtr MarkerValue = new IntPtr(1);

    private readonly IntPtr source;
    private readonly uint sourceProcess;
    private readonly Rect visible;
    private IntPtr popup;
    private uint popupProcess;
    private Rect popupOriginal;
    private Rect popupCropped;
    private IntPtr popupRegion;
    private string popupProperty;
    private DragStrip dragStrip;
    private bool wasDragged;

    public bool WasDragged { get { return wasDragged || (dragStrip != null && dragStrip.WasDragged); } }

    private FrameWindow(IntPtr source, uint sourceProcess, Rect visible)
    {
        this.source = source;
        this.sourceProcess = sourceProcess;
        this.visible = visible;
    }

    public static FrameWindow Capture(string token)
    {
        using (new DpiScope())
        {
            IntPtr handle = FindBrowser(token, IntPtr.Zero, 0);
            uint process;
            if (GetWindowThreadProcessId(handle, out process) == 0)
                throw LastError("Could not identify the browser process.");
            Rect frame;
            if (DwmGetWindowAttribute(handle, DwmExtendedFrameBounds, out frame,
                Marshal.SizeOf(typeof(Rect))) != 0 || frame.Width <= 0 || frame.Height <= 0)
                throw new InvalidOperationException("Could not measure the visible browser window.");
            return new FrameWindow(handle, process, frame);
        }
    }

    public void Hide(string token, double viewportHeight, double viewportWidth, double devicePixelRatio)
    {
        if (popup != IntPtr.Zero) throw new InvalidOperationException("The frame is already hidden.");
        if (!(viewportWidth > 0 && viewportWidth <= 32768 && viewportHeight > 0 && viewportHeight <= 32768) ||
            double.IsNaN(devicePixelRatio) ||
            devicePixelRatio <= 0 || devicePixelRatio > 16)
            throw new ArgumentException("Invalid browser viewport.");

        using (new DpiScope())
        {
            IntPtr handle = FindBrowser(token, source, sourceProcess);
            Rect outer = WindowBounds(handle);
            Rect client = ClientBounds(handle);
            uint dpi = GetDpiForWindow(handle);
            int webWidth = checked((int)Math.Round(viewportWidth * devicePixelRatio));
            int webHeight = checked((int)Math.Round(viewportHeight * devicePixelRatio));
            int topInset = client.Bottom - webHeight - outer.Top;
            int leftInset = client.Left - outer.Left;
            int rightInset = outer.Right - client.Right;
            int bottomInset = outer.Bottom - client.Bottom;
            int maxToolbar = (int)Math.Ceiling(220.0 * dpi / 96);
            int rounding = (int)Math.Ceiling(devicePixelRatio);
            if (dpi == 0 || Math.Abs(client.Width - webWidth) > rounding ||
                webHeight > client.Height + rounding || topInset < 0 || topInset > maxToolbar ||
                leftInset < 0 || rightInset < 0 || bottomInset < 0)
                throw new InvalidOperationException("The browser viewport does not match the native window.");

            popupOriginal = outer;
            popupProperty = "QuietView.Frame." + token;
            GetWindowThreadProcessId(handle, out popupProcess);
            if (popupProcess != sourceProcess || !SetProp(handle, popupProperty, MarkerValue))
                throw LastError("Could not mark the browser window.");
            popup = handle;

            try
            {
                popupRegion = CopyRegion(handle);
                int stripHeight = Math.Min((int)Math.Round(38.0 * dpi / 96), visible.Height / 4);
                // Give the solid strip one pixel of overlap with the page at the seam.
                int contentTop = visible.Top + Math.Max(0, stripHeight - 1);
                Rect targetOuter = new Rect
                {
                    Left = visible.Left - leftInset,
                    Top = contentTop - topInset,
                    Right = visible.Right + rightInset,
                    Bottom = visible.Bottom + bottomInset
                };
                SetBounds(handle, targetOuter);
                Rect actual = WindowBounds(handle);
                Rect newClient = ClientBounds(handle);
                if (!actual.EqualsRect(targetOuter) || GetDpiForWindow(handle) != dpi ||
                    newClient.Left != visible.Left || newClient.Right != visible.Right ||
                    newClient.Bottom != visible.Bottom)
                    throw new InvalidOperationException("Windows changed the requested visible bounds.");

                Rect clip = new Rect
                {
                    Left = visible.Left - actual.Left,
                    Top = contentTop - actual.Top,
                    Right = visible.Right - actual.Left,
                    Bottom = visible.Bottom - actual.Top
                };
                IntPtr region = CreateRectRgn(clip.Left, clip.Top, clip.Right, clip.Bottom);
                if (region == IntPtr.Zero) throw LastError("Could not create the window clip.");
                if (SetWindowRgn(handle, region, true) == 0)
                {
                    DeleteObject(region);
                    throw LastError("Could not apply the window clip.");
                }

                Rect applied;
                if (GetWindowRgnBox(handle, out applied) != 2 || !applied.EqualsRect(clip) ||
                    !WindowBounds(handle).EqualsRect(targetOuter))
                    throw new InvalidOperationException("Could not verify the browser window clip.");
                popupCropped = targetOuter;
                dragStrip = new DragStrip(handle, popupProperty,
                    new Rectangle(visible.Left, visible.Top, visible.Width, stripHeight), dpi);
            }
            catch
            {
                try { Restore(); } catch { }
                throw;
            }
        }
    }

    public void Dispose()
    {
        using (new DpiScope()) Restore();
    }

    private void Restore()
    {
        if (popup == IntPtr.Zero) return;
        if (dragStrip != null)
        {
            dragStrip.Dispose();
            wasDragged = dragStrip.WasDragged;
            dragStrip = null;
        }
        try
        {
            uint process;
            if (GetWindowThreadProcessId(popup, out process) == 0 || process != popupProcess ||
                GetProp(popup, popupProperty) != MarkerValue) return;

            try
            {
                Rect restored = popupOriginal;
                if (wasDragged)
                {
                    Rect current = WindowBounds(popup);
                    int dx = current.Left - popupCropped.Left;
                    int dy = current.Top - popupCropped.Top;
                    restored.Left += dx;
                    restored.Right += dx;
                    restored.Top += dy;
                    restored.Bottom += dy;
                }
                SetBounds(popup, restored);
            }
            finally
            {
                if (SetWindowRgn(popup, popupRegion, true) != 0) popupRegion = IntPtr.Zero;
                RemoveProp(popup, popupProperty);
            }
        }
        finally
        {
            if (popupRegion != IntPtr.Zero) DeleteObject(popupRegion);
            popupRegion = IntPtr.Zero;
            popup = IntPtr.Zero;
        }
    }

    private static IntPtr CopyRegion(IntPtr handle)
    {
        IntPtr copy = CreateRectRgn(0, 0, 0, 0);
        if (copy == IntPtr.Zero) throw LastError("Could not save the browser window clip.");
        if (GetWindowRgn(handle, copy) != 0) return copy;
        DeleteObject(copy);
        return IntPtr.Zero;
    }

    private static IntPtr FindBrowser(string token, IntPtr excluded, uint requiredProcess)
    {
        if (String.IsNullOrWhiteSpace(token) || token.Length < 16 || token.Length > 120)
            throw new ArgumentException("Invalid browser window marker.");

        for (int attempt = 0; attempt < 30; attempt++)
        {
            var matches = new List<IntPtr>();
            var windowClass = new StringBuilder(64);
            var title = new StringBuilder(512);
            EnumWindows(delegate(IntPtr handle, IntPtr parameter)
            {
                if (handle == excluded || !IsWindowVisible(handle) || IsIconic(handle)) return true;
                if (GetClassName(handle, windowClass, windowClass.Capacity) == 0 ||
                    windowClass.ToString() != "Chrome_WidgetWin_1") return true;
                if (GetWindowText(handle, title, title.Capacity) != 0 && MatchesTitle(title.ToString(), token) &&
                    IsBrowserProcess(handle, requiredProcess))
                    matches.Add(handle);
                return true;
            }, IntPtr.Zero);

            if (matches.Count == 1) return matches[0];
            if (matches.Count > 1) throw new InvalidOperationException("The browser window marker is ambiguous.");
            Thread.Sleep(35);
        }
        throw new InvalidOperationException("Could not find the marked browser window.");
    }

    private static bool MatchesTitle(string title, string token)
    {
        // Edge appends a localized tab count and profile name after the active tab's title.
        return title.StartsWith(token, StringComparison.Ordinal) &&
            (title.Length == token.Length || Char.IsWhiteSpace(title[token.Length]));
    }

    private static bool IsBrowserProcess(IntPtr handle, uint requiredProcess)
    {
        uint processId;
        if (GetWindowThreadProcessId(handle, out processId) == 0 ||
            (requiredProcess != 0 && processId != requiredProcess)) return false;
        IntPtr process = OpenProcess(QueryLimitedInformation, false, processId);
        if (process == IntPtr.Zero) return false;
        try
        {
            var path = new StringBuilder(32768);
            int length = path.Capacity;
            if (!QueryFullProcessImageName(process, 0, path, ref length)) return false;
            string filename = Path.GetFileName(path.ToString());
            return String.Equals(filename, "chrome.exe", StringComparison.OrdinalIgnoreCase) ||
                String.Equals(filename, "msedge.exe", StringComparison.OrdinalIgnoreCase);
        }
        finally { CloseHandle(process); }
    }

    private static Rect WindowBounds(IntPtr handle)
    {
        Rect result;
        if (!GetWindowRect(handle, out result)) throw LastError("Could not read browser window bounds.");
        return result;
    }

    private static Rect ClientBounds(IntPtr handle)
    {
        Rect client;
        Point origin = new Point();
        if (!GetClientRect(handle, out client) || !ClientToScreen(handle, ref origin))
            throw LastError("Could not read browser viewport bounds.");
        return new Rect { Left = origin.X, Top = origin.Y, Right = origin.X + client.Width,
            Bottom = origin.Y + client.Height };
    }

    private static void SetBounds(IntPtr handle, Rect bounds)
    {
        if (!SetWindowPos(handle, IntPtr.Zero, bounds.Left, bounds.Top, bounds.Width, bounds.Height,
            NoZOrderOrActivate)) throw LastError("Could not position the browser window.");
    }

    private static Win32Exception LastError(string message)
    {
        return new Win32Exception(Marshal.GetLastWin32Error(), message);
    }

    internal sealed class DpiScope : IDisposable
    {
        private readonly IntPtr previous = SetThreadDpiAwarenessContext(PerMonitorAwareV2);

        public DpiScope()
        {
            if (previous == IntPtr.Zero) throw LastError("Could not read physical screen coordinates.");
        }

        public void Dispose() { SetThreadDpiAwarenessContext(previous); }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Rect
    {
        public int Left, Top, Right, Bottom;
        public int Width { get { return Right - Left; } }
        public int Height { get { return Bottom - Top; } }

        public bool EqualsRect(Rect other)
        {
            return Left == other.Left && Top == other.Top && Right == other.Right && Bottom == other.Bottom;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Point { public int X, Y; }

    private delegate bool WindowCallback(IntPtr handle, IntPtr parameter);

    [DllImport("dwmapi.dll")]
    private static extern int DwmGetWindowAttribute(IntPtr hwnd, int attribute, out Rect value, int size);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll")]
    private static extern uint GetDpiForWindow(IntPtr hwnd);
    [DllImport("user32.dll")]
    private static extern bool EnumWindows(WindowCallback callback, IntPtr parameter);
    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")]
    private static extern bool IsIconic(IntPtr hwnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hwnd, StringBuilder title, int capacity);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr hwnd, StringBuilder name, int capacity);
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint process);
    [DllImport("kernel32.dll")]
    private static extern IntPtr OpenProcess(uint access, bool inherit, uint process);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    private static extern bool QueryFullProcessImageName(IntPtr process, uint flags, StringBuilder path, ref int size);
    [DllImport("kernel32.dll")]
    private static extern bool CloseHandle(IntPtr handle);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool GetWindowRect(IntPtr hwnd, out Rect rect);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool GetClientRect(IntPtr hwnd, out Rect rect);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool ClientToScreen(IntPtr hwnd, ref Point point);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern int SetWindowRgn(IntPtr hwnd, IntPtr region, bool redraw);
    [DllImport("user32.dll")]
    private static extern int GetWindowRgn(IntPtr hwnd, IntPtr region);
    [DllImport("user32.dll")]
    private static extern int GetWindowRgnBox(IntPtr hwnd, out Rect rect);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool SetProp(IntPtr hwnd, string name, IntPtr value);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr GetProp(IntPtr hwnd, string name);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr RemoveProp(IntPtr hwnd, string name);
    [DllImport("gdi32.dll", SetLastError = true)]
    private static extern IntPtr CreateRectRgn(int left, int top, int right, int bottom);
    [DllImport("gdi32.dll")]
    private static extern bool DeleteObject(IntPtr handle);
}
