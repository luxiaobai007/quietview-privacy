using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

internal sealed class DragStrip : IDisposable
{
    private const int CloseMessage = 0x0010;
    private readonly ManualResetEventSlim ready = new ManualResetEventSlim();
    private readonly Thread thread;
    private IntPtr handle;
    private Exception failure;
    private volatile bool stopping;
    private volatile bool wasDragged;

    public bool WasDragged { get { return wasDragged; } }

    public DragStrip(IntPtr owner, string ownerProperty, Rectangle bounds, uint dpi)
    {
        thread = new Thread(() => Run(owner, ownerProperty, bounds, dpi)) { IsBackground = true };
        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        if (!ready.Wait(2500) || failure != null || handle == IntPtr.Zero)
        {
            Dispose();
            throw new InvalidOperationException("Could not show the draggable window grip." +
                (failure == null ? String.Empty : " " + failure.Message), failure);
        }
    }

    private void Run(IntPtr owner, string ownerProperty, Rectangle bounds, uint dpi)
    {
        try
        {
            using (new FrameWindow.DpiScope())
            using (var form = new GripForm(owner, ownerProperty, bounds, dpi, () => stopping,
                () => wasDragged = true))
            {
                form.Shown += delegate
                {
                    try
                    {
                        if (stopping) { form.Close(); return; }
                        form.VerifyBounds(bounds);
                        Interlocked.Exchange(ref handle, form.Handle);
                    }
                    catch (Exception error) { failure = error; form.Close(); }
                    finally { ready.Set(); }
                };
                form.FormClosed += delegate { Interlocked.Exchange(ref handle, IntPtr.Zero); };
                Application.Run(form);
            }
        }
        catch (Exception error) { failure = error; }
        finally { ready.Set(); }
    }

    public void Dispose()
    {
        if (stopping) return;
        stopping = true;
        IntPtr current = Interlocked.Exchange(ref handle, IntPtr.Zero);
        if (current != IntPtr.Zero) PostMessage(current, CloseMessage, IntPtr.Zero, IntPtr.Zero);
        if (thread.Join(2000)) ready.Dispose();
    }

    private sealed class GripForm : Form
    {
        private const int MouseActivate = 0x0021;
        private const int NoActivate = 3;
        private const int Popup = unchecked((int)0x80000000);
        private const int NoActivateToolWindow = 0x08000000 | 0x00000080;
        private const int OwnerIndex = -8;
        private const uint OwnerWindow = 4;
        private const int LeftMouseButton = 0x01;
        private const uint NoZOrderOrActivate = 0x0004 | 0x0010;
        private const uint MoveOnly = 0x0001 | NoZOrderOrActivate;
        private const uint NearestMonitor = 2;
        private static readonly Color Fill = Color.FromArgb(247, 248, 250);
        private static readonly Color Grip = Color.FromArgb(145, 153, 165);
        private readonly IntPtr owner;
        private readonly string ownerProperty;
        private readonly uint dpi;
        private readonly Func<bool> stopping;
        private readonly Action moved;
        private readonly System.Windows.Forms.Timer dragTimer;
        private Point dragOrigin;
        private Rect ownerOrigin;
        private Rect stripOrigin;

        public GripForm(IntPtr owner, string ownerProperty, Rectangle bounds, uint dpi,
            Func<bool> stopping, Action moved)
        {
            this.owner = owner;
            this.ownerProperty = ownerProperty;
            this.dpi = dpi;
            this.stopping = stopping;
            this.moved = moved;
            Text = "QuietView Drag Strip";
            AutoScaleMode = AutoScaleMode.None;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            BackColor = Fill;
            Cursor = Cursors.SizeAll;
            DoubleBuffered = true;
            Bounds = bounds;
            dragTimer = new System.Windows.Forms.Timer { Interval = 16 };
            dragTimer.Tick += delegate { UpdateDrag(); };
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams parameters = base.CreateParams;
                parameters.Parent = owner;
                parameters.Style |= Popup;
                parameters.ExStyle |= NoActivateToolWindow;
                return parameters;
            }
        }

        public void VerifyBounds(Rectangle bounds)
        {
            int noRounding = 1;
            DwmSetWindowAttribute(Handle, 33, ref noRounding, sizeof(int));
            // WinForms can assign its own hidden owner when it removes the taskbar button.
            if (GetWindow(Handle, OwnerWindow) != owner)
            {
                if (IntPtr.Size == 8) SetWindowLongPtr(Handle, OwnerIndex, owner);
                else SetWindowLong(Handle, OwnerIndex, owner.ToInt32());
            }
            if (GetWindow(Handle, OwnerWindow) != owner)
                throw new Win32Exception(Marshal.GetLastWin32Error(), "Could not link the grip to the browser window.");
            if (!SetWindowPos(Handle, IntPtr.Zero, bounds.X, bounds.Y, bounds.Width, bounds.Height, NoZOrderOrActivate))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "Could not place the draggable grip.");
            Rect actual;
            if (!GetWindowRect(Handle, out actual) || actual.Left != bounds.Left || actual.Top != bounds.Top ||
                actual.Right != bounds.Right || actual.Bottom != bounds.Bottom)
                throw new InvalidOperationException("Windows changed the requested grip bounds.");
        }

        protected override void OnPaint(PaintEventArgs args)
        {
            base.OnPaint(args);
            int width = Math.Min(ClientSize.Width, (int)Math.Round(40.0 * dpi / 96));
            int height = Math.Max(2, (int)Math.Round(3.0 * dpi / 96));
            using (var brush = new SolidBrush(Grip))
                args.Graphics.FillRectangle(brush, (ClientSize.Width - width) / 2,
                    (ClientSize.Height - height) / 2, width, height);
        }

        protected override void WndProc(ref Message message)
        {
            if (message.Msg == MouseActivate)
            {
                message.Result = new IntPtr(NoActivate);
                return;
            }
            base.WndProc(ref message);
        }

        protected override void OnMouseDown(MouseEventArgs args)
        {
            base.OnMouseDown(args);
            if (args.Button != MouseButtons.Left || stopping() || !OwnsBrowser() ||
                !GetCursorPos(out dragOrigin) || !GetWindowRect(owner, out ownerOrigin) ||
                !GetWindowRect(Handle, out stripOrigin)) return;
            if (GetForegroundWindow() != owner) SetForegroundWindow(owner);
            Capture = false;
            dragTimer.Start();
        }

        protected override void OnMouseUp(MouseEventArgs args)
        {
            base.OnMouseUp(args);
            if (args.Button == MouseButtons.Left && dragTimer.Enabled) UpdateDrag();
        }

        private bool OwnsBrowser()
        {
            return GetProp(owner, ownerProperty) != IntPtr.Zero;
        }

        private void UpdateDrag()
        {
            if (stopping() || !OwnsBrowser()) { dragTimer.Stop(); Close(); return; }
            if ((GetAsyncKeyState(LeftMouseButton) & 0x8000) == 0) dragTimer.Stop();
            Point cursor;
            Rect current;
            if (!GetCursorPos(out cursor) || !GetWindowRect(owner, out current)) return;
            int dx = cursor.X - dragOrigin.X;
            int dy = cursor.Y - dragOrigin.Y;
            Rect target = ownerOrigin.Offset(dx, dy);
            if (target.Left == current.Left && target.Top == current.Top) return;

            IntPtr oldMonitor = MonitorFromRect(ref current, NearestMonitor);
            IntPtr newMonitor = MonitorFromRect(ref target, NearestMonitor);
            if (oldMonitor != newMonitor)
            {
                int oldScale, newScale;
                if (GetScaleFactorForMonitor(oldMonitor, out oldScale) != 0 ||
                    GetScaleFactorForMonitor(newMonitor, out newScale) != 0 || oldScale != newScale) return;
            }

            if (!SetWindowPos(owner, IntPtr.Zero, target.Left, target.Top, 0, 0, MoveOnly) ||
                !GetWindowRect(owner, out target)) return;
            if (!SetWindowPos(Handle, IntPtr.Zero, stripOrigin.Left + target.Left - ownerOrigin.Left,
                stripOrigin.Top + target.Top - ownerOrigin.Top, 0, 0, MoveOnly))
            {
                SetWindowPos(owner, IntPtr.Zero, current.Left, current.Top, 0, 0, MoveOnly);
                return;
            }
            if (target.Left != current.Left || target.Top != current.Top) moved();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && dragTimer != null) dragTimer.Dispose();
            base.Dispose(disposing);
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Point { public int X, Y; }

    [StructLayout(LayoutKind.Sequential)]
    private struct Rect
    {
        public int Left, Top, Right, Bottom;

        public Rect Offset(int dx, int dy)
        {
            return new Rect { Left = Left + dx, Top = Top + dy, Right = Right + dx, Bottom = Bottom + dy };
        }
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll")]
    private static extern IntPtr GetWindow(IntPtr hwnd, uint command);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW", SetLastError = true)]
    private static extern IntPtr SetWindowLongPtr(IntPtr hwnd, int index, IntPtr value);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongW", SetLastError = true)]
    private static extern int SetWindowLong(IntPtr hwnd, int index, int value);
    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hwnd, out Rect rect);
    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out Point point);
    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int virtualKey);
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")]
    private static extern bool PostMessage(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr GetProp(IntPtr hwnd, string name);
    [DllImport("user32.dll")]
    private static extern IntPtr MonitorFromRect(ref Rect rect, uint flags);
    [DllImport("shcore.dll")]
    private static extern int GetScaleFactorForMonitor(IntPtr monitor, out int scale);
    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);
}
