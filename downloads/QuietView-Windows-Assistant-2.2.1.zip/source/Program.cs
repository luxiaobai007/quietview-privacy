using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

internal static class Program
{
    private const string OriginPrefix = "chrome-extension://";
    private const int MaxMessageBytes = 4096;
    private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = MaxMessageBytes };
    private static readonly Regex TokenPattern = new Regex("^QuietView-[0-9a-f]{32}$", RegexOptions.CultureInvariant);
    private static readonly Regex StoreIdPattern = new Regex(@"\A[a-p]{32}\z", RegexOptions.CultureInvariant);

    public sealed class Request
    {
        public int seq { get; set; }
        public string type { get; set; }
        public string token { get; set; }
        public double viewportHeight { get; set; }
        public double viewportWidth { get; set; }
        public double devicePixelRatio { get; set; }
    }

    private static void Main(string[] args)
    {
        if (args.Length == 0 || !IsAllowedOrigin(args[0])) return;

        FrameWindow frame = null;
        try
        {
            using (var input = new BinaryReader(Console.OpenStandardInput(), Utf8))
            using (var output = new BinaryWriter(Console.OpenStandardOutput(), Utf8))
            {
                while (true)
                {
                    int length;
                    try { length = input.ReadInt32(); }
                    catch (EndOfStreamException) { return; }
                    if (length < 1 || length > MaxMessageBytes) return;
                    byte[] body = input.ReadBytes(length);
                    if (body.Length != length) return;

                    object response;
                    int seq = 0;
                    bool moved = false;
                    try
                    {
                        var request = Json.Deserialize<Request>(Utf8.GetString(body));
                        seq = request.seq;
                        switch (request.type)
                        {
                            case "capture":
                                CheckToken(request.token);
                                if (frame != null) throw new InvalidOperationException("frame-already-captured");
                                frame = FrameWindow.Capture(request.token);
                                break;
                            case "hide":
                                CheckToken(request.token);
                                if (frame == null || request.viewportWidth < 1 || request.viewportHeight < 1 ||
                                    request.viewportWidth > 32768 || request.viewportHeight > 32768 ||
                                    !(request.devicePixelRatio >= 0.1 && request.devicePixelRatio <= 16))
                                    throw new InvalidOperationException("invalid-viewport");
                                frame.Hide(request.token, request.viewportHeight, request.viewportWidth,
                                    request.devicePixelRatio);
                                break;
                            case "release":
                                if (frame != null)
                                {
                                    frame.Dispose();
                                    moved = frame.WasDragged;
                                }
                                frame = null;
                                break;
                            default:
                                throw new InvalidOperationException("unknown-command");
                        }
                        response = new { seq, ok = true, protocol = 2, moved };
                    }
                    catch (Exception error)
                    {
                        Console.Error.WriteLine(error.GetType().Name + ": " + error.Message);
                        response = new { seq, ok = false, error = "frame-operation-failed" };
                    }

                    byte[] reply = Utf8.GetBytes(Json.Serialize(response));
                    output.Write(reply.Length);
                    output.Write(reply);
                    output.Flush();
                }
            }
        }
        catch (IOException) { }
        finally
        {
            if (frame != null) frame.Dispose();
        }
    }

    private static void CheckToken(string token)
    {
        if (token == null || !TokenPattern.IsMatch(token))
            throw new InvalidOperationException("invalid-window-token");
    }

    private static bool IsAllowedOrigin(string origin)
    {
        try
        {
            string config = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "store-ids.json");
            var settings = Json.Deserialize<Dictionary<string, string>>(File.ReadAllText(config, Utf8));
            string chrome;
            string edge;
            if (settings == null || !settings.TryGetValue("chromeExtensionId", out chrome) ||
                !settings.TryGetValue("edgeExtensionId", out edge) || !IsStoreId(chrome) || !IsStoreId(edge))
                return false;

            return MatchesOrigin(origin, chrome) || MatchesOrigin(origin, edge);
        }
        catch (IOException) { return false; }
        catch (UnauthorizedAccessException) { return false; }
        catch (ArgumentException) { return false; }
        catch (InvalidOperationException) { return false; }
    }

    private static bool IsStoreId(string id)
    {
        return id != null && (id.Length == 0 || StoreIdPattern.IsMatch(id));
    }

    private static bool MatchesOrigin(string origin, string extensionId)
    {
        return extensionId.Length != 0 && String.Equals(origin, OriginPrefix + extensionId + "/", StringComparison.Ordinal);
    }
}
