@echo off
setlocal DisableDelayedExpansion
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall-QuietView.ps1"
set "quietview_exit=%errorlevel%"
pause
exit /b %quietview_exit%
