﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'

$nativeName = 'local.quietview.frame'
$binaryName = 'QuietView.Host.exe'
$binaryPath = Join-Path $PSScriptRoot $binaryName
$nativeManifestPath = Join-Path $PSScriptRoot "$nativeName.json"
$storeIdsPath = Join-Path $PSScriptRoot 'store-ids.json'

if (-not (Test-Path -LiteralPath $binaryPath -PathType Leaf) -or
    -not (Test-Path -LiteralPath $storeIdsPath -PathType Leaf)) {
    throw '请先完整解压安装包，再运行安装脚本。'
}

$settings = Get-Content -LiteralPath $storeIdsPath -Raw -Encoding UTF8 | ConvertFrom-Json
$storeIds = [ordered]@{
    Chrome = $settings.chromeExtensionId
    Edge = $settings.edgeExtensionId
}
foreach ($store in $storeIds.Keys) {
    $id = $storeIds[$store]
    if ($id -isnot [string] -or ($id -ne '' -and $id -cnotmatch '\A[a-p]{32}\z')) {
        throw "store-ids.json 中的 $store 扩展 ID 无效。"
    }
}

$configuredStores = @($storeIds.Keys | Where-Object { $storeIds[$_] -ne '' })
if ($configuredStores.Count -eq 0) {
    throw '此包尚未配置商店扩展 ID。请在商店创建扩展草稿后配置 store-ids.json，再分发给用户。'
}
$allowedOrigins = @($configuredStores | ForEach-Object { "chrome-extension://$($storeIds[$_])/" } | Select-Object -Unique)

$nativeManifest = [ordered]@{
    name = $nativeName
    description = 'QuietView Windows frame helper'
    path = $binaryName
    type = 'stdio'
    allowed_origins = $allowedOrigins
}
$temporaryManifest = "$nativeManifestPath.$([Guid]::NewGuid().ToString('N')).tmp"
try {
    $json = $nativeManifest | ConvertTo-Json -Compress
    [IO.File]::WriteAllText($temporaryManifest, $json, [Text.UTF8Encoding]::new($false))
    if ([IO.File]::Exists($nativeManifestPath)) {
        [IO.File]::Replace($temporaryManifest, $nativeManifestPath, [NullString]::Value)
    } else {
        [IO.File]::Move($temporaryManifest, $nativeManifestPath)
    }
} finally {
    [IO.File]::Delete($temporaryManifest)
}

$registryPaths = [ordered]@{
    Chrome = "Software\Google\Chrome\NativeMessagingHosts\$nativeName"
    Edge = "Software\Microsoft\Edge\NativeMessagingHosts\$nativeName"
}
$registrationErrors = @()
foreach ($browserName in $configuredStores) {
    $entry = $null
    try {
        $entry = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($registryPaths[$browserName])
        $entry.SetValue('', $nativeManifestPath, [Microsoft.Win32.RegistryValueKind]::String)
        Write-Host "$browserName Windows 组件已注册。"
    } catch {
        $registrationErrors += "$browserName $($_.Exception.Message)"
    } finally {
        if ($entry) { $entry.Dispose() }
    }
}
if ($registrationErrors.Count) {
    throw ('部分注册失败。' + [Environment]::NewLine + ($registrationErrors -join [Environment]::NewLine))
}
Write-Host '安装完成。请返回商店安装的净览扩展，再试一次沉浸模式。'
